<?php
    get_header();
    get_template_part( 'template-parts/content-excerpt' );
    get_footer();
