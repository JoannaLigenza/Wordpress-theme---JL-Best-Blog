<?php
    get_header( 'page' );
?>

<div class="content">

    <div class="main-content container">
        <?php get_template_part( 'template-parts/content' ); ?>
    </div>

</div>





<?php
    get_footer();
?>