<?php
    get_header( 'post' );
?>

<div class="content">

    <div class="main-content container">
        <?php get_template_part( 'template-parts/content' ); ?>
    </div>

</div>

<?php
    get_footer();
?>